export enum Role {
    STAGIAIRE,
    FORMATEUR,
    GESTIONNAIRE,
    ADMINISTRATEUR

}